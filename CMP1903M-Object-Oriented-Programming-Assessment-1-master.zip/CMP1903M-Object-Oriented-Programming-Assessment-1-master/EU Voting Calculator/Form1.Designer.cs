﻿namespace EU_Voting_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.resetAllyes = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.austriaYes = new System.Windows.Forms.CheckBox();
            this.austriaNo = new System.Windows.Forms.CheckBox();
            this.austriaAbstain = new System.Windows.Forms.CheckBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.belgiumAbstain = new System.Windows.Forms.CheckBox();
            this.belgiumNo = new System.Windows.Forms.CheckBox();
            this.belgiumYes = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.bulgariaAbstain = new System.Windows.Forms.CheckBox();
            this.bulgariaNo = new System.Windows.Forms.CheckBox();
            this.bulgariaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.croatiaAbstain = new System.Windows.Forms.CheckBox();
            this.croatiaNo = new System.Windows.Forms.CheckBox();
            this.croatiaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.cyprusAbstain = new System.Windows.Forms.CheckBox();
            this.cyprusNo = new System.Windows.Forms.CheckBox();
            this.cyprusYes = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.czechiaAbstain = new System.Windows.Forms.CheckBox();
            this.czechiaNo = new System.Windows.Forms.CheckBox();
            this.czechiaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.denmarkAbstain = new System.Windows.Forms.CheckBox();
            this.denmarkNo = new System.Windows.Forms.CheckBox();
            this.denmarkYes = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.estoniaAbstain = new System.Windows.Forms.CheckBox();
            this.estoniaNo = new System.Windows.Forms.CheckBox();
            this.estoniaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.finlandAbstain = new System.Windows.Forms.CheckBox();
            this.finlandNo = new System.Windows.Forms.CheckBox();
            this.finlandYes = new System.Windows.Forms.CheckBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.italyAbstain = new System.Windows.Forms.CheckBox();
            this.italyNo = new System.Windows.Forms.CheckBox();
            this.italyYes = new System.Windows.Forms.CheckBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.latviaAbstain = new System.Windows.Forms.CheckBox();
            this.latviaNo = new System.Windows.Forms.CheckBox();
            this.latviaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.lithuaniaAbstain = new System.Windows.Forms.CheckBox();
            this.lithuaniaNo = new System.Windows.Forms.CheckBox();
            this.lithuaniaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.luxembourgAbstain = new System.Windows.Forms.CheckBox();
            this.luxembourgNo = new System.Windows.Forms.CheckBox();
            this.luxembourgYes = new System.Windows.Forms.CheckBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.maltaAbstain = new System.Windows.Forms.CheckBox();
            this.maltaNo = new System.Windows.Forms.CheckBox();
            this.maltaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.netherlandsAbstain = new System.Windows.Forms.CheckBox();
            this.netherlandsNo = new System.Windows.Forms.CheckBox();
            this.netherlandsYes = new System.Windows.Forms.CheckBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.polandAbstain = new System.Windows.Forms.CheckBox();
            this.polandNo = new System.Windows.Forms.CheckBox();
            this.polandYes = new System.Windows.Forms.CheckBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.portugalAbstain = new System.Windows.Forms.CheckBox();
            this.portugalNo = new System.Windows.Forms.CheckBox();
            this.portugalYes = new System.Windows.Forms.CheckBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.romaniaAbstain = new System.Windows.Forms.CheckBox();
            this.romaniaNo = new System.Windows.Forms.CheckBox();
            this.romaniaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.slovakiaAbstain = new System.Windows.Forms.CheckBox();
            this.slovakiaNo = new System.Windows.Forms.CheckBox();
            this.slovakiaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.sloveniaAbstain = new System.Windows.Forms.CheckBox();
            this.sloveniaNo = new System.Windows.Forms.CheckBox();
            this.sloveniaYes = new System.Windows.Forms.CheckBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.spainAbstain = new System.Windows.Forms.CheckBox();
            this.spainNo = new System.Windows.Forms.CheckBox();
            this.spainYes = new System.Windows.Forms.CheckBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.swedenAbstain = new System.Windows.Forms.CheckBox();
            this.swedenNo = new System.Windows.Forms.CheckBox();
            this.swedenYes = new System.Windows.Forms.CheckBox();
            this.resultText = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.requiredText = new System.Windows.Forms.TextBox();
            this.irelandAbstain = new System.Windows.Forms.CheckBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.franceYes = new System.Windows.Forms.CheckBox();
            this.franceNo = new System.Windows.Forms.CheckBox();
            this.franceAbstain = new System.Windows.Forms.CheckBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.germanyYes = new System.Windows.Forms.CheckBox();
            this.germanyNo = new System.Windows.Forms.CheckBox();
            this.germanyAbstain = new System.Windows.Forms.CheckBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.greeceYes = new System.Windows.Forms.CheckBox();
            this.greeceNo = new System.Windows.Forms.CheckBox();
            this.greeceAbstain = new System.Windows.Forms.CheckBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.hungaryYes = new System.Windows.Forms.CheckBox();
            this.hungaryNo = new System.Windows.Forms.CheckBox();
            this.hungaryAbstain = new System.Windows.Forms.CheckBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.irelandYes = new System.Windows.Forms.CheckBox();
            this.irelandNo = new System.Windows.Forms.CheckBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.ruleBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(394, 11);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(348, 45);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "EU Voting Calculator";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 16.25F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(15, 72);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(241, 44);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "Country";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // resetAllyes
            // 
            this.resetAllyes.BackColor = System.Drawing.SystemColors.Control;
            this.resetAllyes.Font = new System.Drawing.Font("Segoe UI", 12.25F, System.Drawing.FontStyle.Bold);
            this.resetAllyes.ForeColor = System.Drawing.SystemColors.ControlText;
            this.resetAllyes.Location = new System.Drawing.Point(964, 662);
            this.resetAllyes.Margin = new System.Windows.Forms.Padding(2);
            this.resetAllyes.Name = "resetAllyes";
            this.resetAllyes.Size = new System.Drawing.Size(179, 34);
            this.resetAllyes.TabIndex = 2;
            this.resetAllyes.Text = "Reset All to Yes";
            this.resetAllyes.UseVisualStyleBackColor = false;
            this.resetAllyes.Click += new System.EventHandler(this.resetAllyes_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::EU_Voting_Calculator.Properties.Resources.Austria;
            this.pictureBox1.Location = new System.Drawing.Point(15, 136);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(62, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // austriaYes
            // 
            this.austriaYes.AutoSize = true;
            this.austriaYes.Checked = true;
            this.austriaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.austriaYes.Location = new System.Drawing.Point(311, 158);
            this.austriaYes.Margin = new System.Windows.Forms.Padding(2);
            this.austriaYes.Name = "austriaYes";
            this.austriaYes.Size = new System.Drawing.Size(18, 17);
            this.austriaYes.TabIndex = 4;
            this.austriaYes.UseVisualStyleBackColor = true;
            this.austriaYes.CheckedChanged += new System.EventHandler(this.austriaYes_CheckedChanged);
            // 
            // austriaNo
            // 
            this.austriaNo.AutoSize = true;
            this.austriaNo.Location = new System.Drawing.Point(339, 158);
            this.austriaNo.Margin = new System.Windows.Forms.Padding(2);
            this.austriaNo.Name = "austriaNo";
            this.austriaNo.Size = new System.Drawing.Size(18, 17);
            this.austriaNo.TabIndex = 5;
            this.austriaNo.UseVisualStyleBackColor = true;
            this.austriaNo.CheckedChanged += new System.EventHandler(this.austriaNo_CheckedChanged);
            // 
            // austriaAbstain
            // 
            this.austriaAbstain.AutoSize = true;
            this.austriaAbstain.Location = new System.Drawing.Point(368, 158);
            this.austriaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.austriaAbstain.Name = "austriaAbstain";
            this.austriaAbstain.Size = new System.Drawing.Size(18, 17);
            this.austriaAbstain.TabIndex = 6;
            this.austriaAbstain.UseVisualStyleBackColor = true;
            this.austriaAbstain.CheckedChanged += new System.EventHandler(this.austriaAbstain_CheckedChanged);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.Control;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(86, 152);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(128, 32);
            this.textBox3.TabIndex = 7;
            this.textBox3.Text = "Austria - 1.98%";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::EU_Voting_Calculator.Properties.Resources.Belgium;
            this.pictureBox2.Location = new System.Drawing.Point(15, 192);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(62, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Control;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(86, 205);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(142, 32);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "Belgium - 2.56%";
            // 
            // belgiumAbstain
            // 
            this.belgiumAbstain.AutoSize = true;
            this.belgiumAbstain.Location = new System.Drawing.Point(368, 210);
            this.belgiumAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.belgiumAbstain.Name = "belgiumAbstain";
            this.belgiumAbstain.Size = new System.Drawing.Size(18, 17);
            this.belgiumAbstain.TabIndex = 12;
            this.belgiumAbstain.UseVisualStyleBackColor = true;
            this.belgiumAbstain.CheckedChanged += new System.EventHandler(this.belgiumAbstain_CheckedChanged);
            // 
            // belgiumNo
            // 
            this.belgiumNo.AutoSize = true;
            this.belgiumNo.Location = new System.Drawing.Point(339, 210);
            this.belgiumNo.Margin = new System.Windows.Forms.Padding(2);
            this.belgiumNo.Name = "belgiumNo";
            this.belgiumNo.Size = new System.Drawing.Size(18, 17);
            this.belgiumNo.TabIndex = 11;
            this.belgiumNo.UseVisualStyleBackColor = true;
            this.belgiumNo.CheckedChanged += new System.EventHandler(this.belgiumNo_CheckedChanged);
            // 
            // belgiumYes
            // 
            this.belgiumYes.AutoSize = true;
            this.belgiumYes.Checked = true;
            this.belgiumYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.belgiumYes.Location = new System.Drawing.Point(311, 210);
            this.belgiumYes.Margin = new System.Windows.Forms.Padding(2);
            this.belgiumYes.Name = "belgiumYes";
            this.belgiumYes.Size = new System.Drawing.Size(18, 17);
            this.belgiumYes.TabIndex = 10;
            this.belgiumYes.UseVisualStyleBackColor = true;
            this.belgiumYes.CheckedChanged += new System.EventHandler(this.belgiumYes_CheckedChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::EU_Voting_Calculator.Properties.Resources.Bulgaria;
            this.pictureBox3.Location = new System.Drawing.Point(15, 249);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(62, 52);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 13;
            this.pictureBox3.TabStop = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Control;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(86, 264);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(142, 32);
            this.textBox5.TabIndex = 14;
            this.textBox5.Text = "Bulgaria - 1.56%";
            // 
            // bulgariaAbstain
            // 
            this.bulgariaAbstain.AutoSize = true;
            this.bulgariaAbstain.Location = new System.Drawing.Point(368, 270);
            this.bulgariaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.bulgariaAbstain.Name = "bulgariaAbstain";
            this.bulgariaAbstain.Size = new System.Drawing.Size(18, 17);
            this.bulgariaAbstain.TabIndex = 17;
            this.bulgariaAbstain.UseVisualStyleBackColor = true;
            this.bulgariaAbstain.CheckedChanged += new System.EventHandler(this.bulgariaAbstain_CheckedChanged);
            // 
            // bulgariaNo
            // 
            this.bulgariaNo.AutoSize = true;
            this.bulgariaNo.Location = new System.Drawing.Point(339, 270);
            this.bulgariaNo.Margin = new System.Windows.Forms.Padding(2);
            this.bulgariaNo.Name = "bulgariaNo";
            this.bulgariaNo.Size = new System.Drawing.Size(18, 17);
            this.bulgariaNo.TabIndex = 16;
            this.bulgariaNo.UseVisualStyleBackColor = true;
            this.bulgariaNo.CheckedChanged += new System.EventHandler(this.bulgariaNo_CheckedChanged);
            // 
            // bulgariaYes
            // 
            this.bulgariaYes.AutoSize = true;
            this.bulgariaYes.Checked = true;
            this.bulgariaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.bulgariaYes.Location = new System.Drawing.Point(311, 270);
            this.bulgariaYes.Margin = new System.Windows.Forms.Padding(2);
            this.bulgariaYes.Name = "bulgariaYes";
            this.bulgariaYes.Size = new System.Drawing.Size(18, 17);
            this.bulgariaYes.TabIndex = 15;
            this.bulgariaYes.UseVisualStyleBackColor = true;
            this.bulgariaYes.CheckedChanged += new System.EventHandler(this.bulgariaYes_CheckedChanged);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::EU_Voting_Calculator.Properties.Resources.Croatia;
            this.pictureBox4.Location = new System.Drawing.Point(15, 306);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(62, 52);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Control;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(85, 323);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(128, 32);
            this.textBox6.TabIndex = 19;
            this.textBox6.Text = "Croatia - 0.91%";
            // 
            // croatiaAbstain
            // 
            this.croatiaAbstain.AutoSize = true;
            this.croatiaAbstain.Location = new System.Drawing.Point(368, 329);
            this.croatiaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.croatiaAbstain.Name = "croatiaAbstain";
            this.croatiaAbstain.Size = new System.Drawing.Size(18, 17);
            this.croatiaAbstain.TabIndex = 22;
            this.croatiaAbstain.UseVisualStyleBackColor = true;
            this.croatiaAbstain.CheckedChanged += new System.EventHandler(this.croatiaAbstain_CheckedChanged);
            // 
            // croatiaNo
            // 
            this.croatiaNo.AutoSize = true;
            this.croatiaNo.Location = new System.Drawing.Point(339, 329);
            this.croatiaNo.Margin = new System.Windows.Forms.Padding(2);
            this.croatiaNo.Name = "croatiaNo";
            this.croatiaNo.Size = new System.Drawing.Size(18, 17);
            this.croatiaNo.TabIndex = 21;
            this.croatiaNo.UseVisualStyleBackColor = true;
            this.croatiaNo.CheckedChanged += new System.EventHandler(this.croatiaNo_CheckedChanged);
            // 
            // croatiaYes
            // 
            this.croatiaYes.AutoSize = true;
            this.croatiaYes.Checked = true;
            this.croatiaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.croatiaYes.Location = new System.Drawing.Point(311, 329);
            this.croatiaYes.Margin = new System.Windows.Forms.Padding(2);
            this.croatiaYes.Name = "croatiaYes";
            this.croatiaYes.Size = new System.Drawing.Size(18, 17);
            this.croatiaYes.TabIndex = 20;
            this.croatiaYes.UseVisualStyleBackColor = true;
            this.croatiaYes.CheckedChanged += new System.EventHandler(this.croatiaYes_CheckedChanged);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::EU_Voting_Calculator.Properties.Resources.Cyprus;
            this.pictureBox5.Location = new System.Drawing.Point(15, 363);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(62, 52);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 23;
            this.pictureBox5.TabStop = false;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Control;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(86, 377);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(128, 32);
            this.textBox7.TabIndex = 24;
            this.textBox7.Text = "Cyprus - 0.20%";
            // 
            // cyprusAbstain
            // 
            this.cyprusAbstain.AutoSize = true;
            this.cyprusAbstain.Location = new System.Drawing.Point(368, 383);
            this.cyprusAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.cyprusAbstain.Name = "cyprusAbstain";
            this.cyprusAbstain.Size = new System.Drawing.Size(18, 17);
            this.cyprusAbstain.TabIndex = 27;
            this.cyprusAbstain.UseVisualStyleBackColor = true;
            this.cyprusAbstain.CheckedChanged += new System.EventHandler(this.cyprusAbstain_CheckedChanged);
            // 
            // cyprusNo
            // 
            this.cyprusNo.AutoSize = true;
            this.cyprusNo.Location = new System.Drawing.Point(339, 383);
            this.cyprusNo.Margin = new System.Windows.Forms.Padding(2);
            this.cyprusNo.Name = "cyprusNo";
            this.cyprusNo.Size = new System.Drawing.Size(18, 17);
            this.cyprusNo.TabIndex = 26;
            this.cyprusNo.UseVisualStyleBackColor = true;
            this.cyprusNo.CheckedChanged += new System.EventHandler(this.cyprusNo_CheckedChanged);
            // 
            // cyprusYes
            // 
            this.cyprusYes.AutoSize = true;
            this.cyprusYes.Checked = true;
            this.cyprusYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cyprusYes.Location = new System.Drawing.Point(311, 383);
            this.cyprusYes.Margin = new System.Windows.Forms.Padding(2);
            this.cyprusYes.Name = "cyprusYes";
            this.cyprusYes.Size = new System.Drawing.Size(18, 17);
            this.cyprusYes.TabIndex = 25;
            this.cyprusYes.UseVisualStyleBackColor = true;
            this.cyprusYes.CheckedChanged += new System.EventHandler(this.cyprusYes_CheckedChanged);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::EU_Voting_Calculator.Properties.Resources.Czechia;
            this.pictureBox6.Location = new System.Drawing.Point(15, 420);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(62, 52);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 28;
            this.pictureBox6.TabStop = false;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Control;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(86, 438);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(197, 32);
            this.textBox8.TabIndex = 29;
            this.textBox8.Text = "Czech Republic - 2.35%";
            // 
            // czechiaAbstain
            // 
            this.czechiaAbstain.AutoSize = true;
            this.czechiaAbstain.Location = new System.Drawing.Point(368, 440);
            this.czechiaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.czechiaAbstain.Name = "czechiaAbstain";
            this.czechiaAbstain.Size = new System.Drawing.Size(18, 17);
            this.czechiaAbstain.TabIndex = 32;
            this.czechiaAbstain.UseVisualStyleBackColor = true;
            this.czechiaAbstain.CheckedChanged += new System.EventHandler(this.czechiaAbstain_CheckedChanged);
            // 
            // czechiaNo
            // 
            this.czechiaNo.AutoSize = true;
            this.czechiaNo.Location = new System.Drawing.Point(339, 440);
            this.czechiaNo.Margin = new System.Windows.Forms.Padding(2);
            this.czechiaNo.Name = "czechiaNo";
            this.czechiaNo.Size = new System.Drawing.Size(18, 17);
            this.czechiaNo.TabIndex = 31;
            this.czechiaNo.UseVisualStyleBackColor = true;
            this.czechiaNo.CheckedChanged += new System.EventHandler(this.czechiaNo_CheckedChanged);
            // 
            // czechiaYes
            // 
            this.czechiaYes.AutoSize = true;
            this.czechiaYes.Checked = true;
            this.czechiaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.czechiaYes.Location = new System.Drawing.Point(311, 440);
            this.czechiaYes.Margin = new System.Windows.Forms.Padding(2);
            this.czechiaYes.Name = "czechiaYes";
            this.czechiaYes.Size = new System.Drawing.Size(18, 17);
            this.czechiaYes.TabIndex = 30;
            this.czechiaYes.UseVisualStyleBackColor = true;
            this.czechiaYes.CheckedChanged += new System.EventHandler(this.czechiaYes_CheckedChanged);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::EU_Voting_Calculator.Properties.Resources.Denmark;
            this.pictureBox7.Location = new System.Drawing.Point(15, 477);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(62, 52);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 33;
            this.pictureBox7.TabStop = false;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Control;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(86, 492);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(149, 32);
            this.textBox9.TabIndex = 34;
            this.textBox9.Text = "Denmark - 1.30%";
            // 
            // denmarkAbstain
            // 
            this.denmarkAbstain.AutoSize = true;
            this.denmarkAbstain.Location = new System.Drawing.Point(368, 498);
            this.denmarkAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.denmarkAbstain.Name = "denmarkAbstain";
            this.denmarkAbstain.Size = new System.Drawing.Size(18, 17);
            this.denmarkAbstain.TabIndex = 37;
            this.denmarkAbstain.UseVisualStyleBackColor = true;
            this.denmarkAbstain.CheckedChanged += new System.EventHandler(this.denmarkAbstain_CheckedChanged);
            // 
            // denmarkNo
            // 
            this.denmarkNo.AutoSize = true;
            this.denmarkNo.Location = new System.Drawing.Point(339, 498);
            this.denmarkNo.Margin = new System.Windows.Forms.Padding(2);
            this.denmarkNo.Name = "denmarkNo";
            this.denmarkNo.Size = new System.Drawing.Size(18, 17);
            this.denmarkNo.TabIndex = 36;
            this.denmarkNo.UseVisualStyleBackColor = true;
            this.denmarkNo.CheckedChanged += new System.EventHandler(this.denmarkNo_CheckedChanged);
            // 
            // denmarkYes
            // 
            this.denmarkYes.AutoSize = true;
            this.denmarkYes.Checked = true;
            this.denmarkYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.denmarkYes.Location = new System.Drawing.Point(311, 498);
            this.denmarkYes.Margin = new System.Windows.Forms.Padding(2);
            this.denmarkYes.Name = "denmarkYes";
            this.denmarkYes.Size = new System.Drawing.Size(18, 17);
            this.denmarkYes.TabIndex = 35;
            this.denmarkYes.UseVisualStyleBackColor = true;
            this.denmarkYes.CheckedChanged += new System.EventHandler(this.denmarkYes_CheckedChanged);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::EU_Voting_Calculator.Properties.Resources.Estonia;
            this.pictureBox8.Location = new System.Drawing.Point(15, 533);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(62, 52);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 38;
            this.pictureBox8.TabStop = false;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Control;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(86, 550);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(128, 32);
            this.textBox10.TabIndex = 39;
            this.textBox10.Text = "Estonia - 0.30%";
            // 
            // estoniaAbstain
            // 
            this.estoniaAbstain.AutoSize = true;
            this.estoniaAbstain.Location = new System.Drawing.Point(368, 555);
            this.estoniaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.estoniaAbstain.Name = "estoniaAbstain";
            this.estoniaAbstain.Size = new System.Drawing.Size(18, 17);
            this.estoniaAbstain.TabIndex = 42;
            this.estoniaAbstain.UseVisualStyleBackColor = true;
            this.estoniaAbstain.CheckedChanged += new System.EventHandler(this.estoniaAbstain_CheckedChanged);
            // 
            // estoniaNo
            // 
            this.estoniaNo.AutoSize = true;
            this.estoniaNo.Location = new System.Drawing.Point(339, 555);
            this.estoniaNo.Margin = new System.Windows.Forms.Padding(2);
            this.estoniaNo.Name = "estoniaNo";
            this.estoniaNo.Size = new System.Drawing.Size(18, 17);
            this.estoniaNo.TabIndex = 41;
            this.estoniaNo.UseVisualStyleBackColor = true;
            this.estoniaNo.CheckedChanged += new System.EventHandler(this.estoniaNo_CheckedChanged);
            // 
            // estoniaYes
            // 
            this.estoniaYes.AutoSize = true;
            this.estoniaYes.Checked = true;
            this.estoniaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.estoniaYes.Location = new System.Drawing.Point(311, 555);
            this.estoniaYes.Margin = new System.Windows.Forms.Padding(2);
            this.estoniaYes.Name = "estoniaYes";
            this.estoniaYes.Size = new System.Drawing.Size(18, 17);
            this.estoniaYes.TabIndex = 40;
            this.estoniaYes.UseVisualStyleBackColor = true;
            this.estoniaYes.CheckedChanged += new System.EventHandler(this.estoniaYes_CheckedChanged);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::EU_Voting_Calculator.Properties.Resources.Finland;
            this.pictureBox9.Location = new System.Drawing.Point(15, 590);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(62, 52);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 43;
            this.pictureBox9.TabStop = false;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.Control;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(86, 606);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(133, 32);
            this.textBox11.TabIndex = 44;
            this.textBox11.Text = "Finland - 1.23%";
            // 
            // finlandAbstain
            // 
            this.finlandAbstain.AutoSize = true;
            this.finlandAbstain.Location = new System.Drawing.Point(368, 611);
            this.finlandAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.finlandAbstain.Name = "finlandAbstain";
            this.finlandAbstain.Size = new System.Drawing.Size(18, 17);
            this.finlandAbstain.TabIndex = 47;
            this.finlandAbstain.UseVisualStyleBackColor = true;
            this.finlandAbstain.CheckedChanged += new System.EventHandler(this.finlandAbstain_CheckedChanged);
            // 
            // finlandNo
            // 
            this.finlandNo.AutoSize = true;
            this.finlandNo.Location = new System.Drawing.Point(339, 611);
            this.finlandNo.Margin = new System.Windows.Forms.Padding(2);
            this.finlandNo.Name = "finlandNo";
            this.finlandNo.Size = new System.Drawing.Size(18, 17);
            this.finlandNo.TabIndex = 46;
            this.finlandNo.UseVisualStyleBackColor = true;
            this.finlandNo.CheckedChanged += new System.EventHandler(this.finlandNo_CheckedChanged);
            // 
            // finlandYes
            // 
            this.finlandYes.AutoSize = true;
            this.finlandYes.Checked = true;
            this.finlandYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.finlandYes.Location = new System.Drawing.Point(311, 611);
            this.finlandYes.Margin = new System.Windows.Forms.Padding(2);
            this.finlandYes.Name = "finlandYes";
            this.finlandYes.Size = new System.Drawing.Size(18, 17);
            this.finlandYes.TabIndex = 45;
            this.finlandYes.UseVisualStyleBackColor = true;
            this.finlandYes.CheckedChanged += new System.EventHandler(this.finlandYes_CheckedChanged);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::EU_Voting_Calculator.Properties.Resources.Italy;
            this.pictureBox15.Location = new System.Drawing.Point(407, 420);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(62, 52);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 73;
            this.pictureBox15.TabStop = false;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.Control;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox17.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(478, 436);
            this.textBox17.Margin = new System.Windows.Forms.Padding(2);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(119, 32);
            this.textBox17.TabIndex = 74;
            this.textBox17.Text = "Italy - 13.65%";
            // 
            // italyAbstain
            // 
            this.italyAbstain.AutoSize = true;
            this.italyAbstain.Location = new System.Drawing.Point(740, 442);
            this.italyAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.italyAbstain.Name = "italyAbstain";
            this.italyAbstain.Size = new System.Drawing.Size(18, 17);
            this.italyAbstain.TabIndex = 77;
            this.italyAbstain.UseVisualStyleBackColor = true;
            this.italyAbstain.CheckedChanged += new System.EventHandler(this.italyAbstain_CheckedChanged);
            // 
            // italyNo
            // 
            this.italyNo.AutoSize = true;
            this.italyNo.Location = new System.Drawing.Point(711, 442);
            this.italyNo.Margin = new System.Windows.Forms.Padding(2);
            this.italyNo.Name = "italyNo";
            this.italyNo.Size = new System.Drawing.Size(18, 17);
            this.italyNo.TabIndex = 76;
            this.italyNo.UseVisualStyleBackColor = true;
            this.italyNo.CheckedChanged += new System.EventHandler(this.italyNo_CheckedChanged);
            // 
            // italyYes
            // 
            this.italyYes.AutoSize = true;
            this.italyYes.Checked = true;
            this.italyYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.italyYes.Location = new System.Drawing.Point(682, 442);
            this.italyYes.Margin = new System.Windows.Forms.Padding(2);
            this.italyYes.Name = "italyYes";
            this.italyYes.Size = new System.Drawing.Size(18, 17);
            this.italyYes.TabIndex = 75;
            this.italyYes.UseVisualStyleBackColor = true;
            this.italyYes.CheckedChanged += new System.EventHandler(this.italyYes_CheckedChanged);
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::EU_Voting_Calculator.Properties.Resources.Latvia;
            this.pictureBox16.Location = new System.Drawing.Point(407, 476);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(62, 52);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 78;
            this.pictureBox16.TabStop = false;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.SystemColors.Control;
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(478, 489);
            this.textBox18.Margin = new System.Windows.Forms.Padding(2);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(119, 32);
            this.textBox18.TabIndex = 79;
            this.textBox18.Text = "Latvia - 0.43%";
            // 
            // latviaAbstain
            // 
            this.latviaAbstain.AutoSize = true;
            this.latviaAbstain.Location = new System.Drawing.Point(740, 494);
            this.latviaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.latviaAbstain.Name = "latviaAbstain";
            this.latviaAbstain.Size = new System.Drawing.Size(18, 17);
            this.latviaAbstain.TabIndex = 82;
            this.latviaAbstain.UseVisualStyleBackColor = true;
            this.latviaAbstain.CheckedChanged += new System.EventHandler(this.latviaAbstain_CheckedChanged);
            // 
            // latviaNo
            // 
            this.latviaNo.AutoSize = true;
            this.latviaNo.Location = new System.Drawing.Point(711, 494);
            this.latviaNo.Margin = new System.Windows.Forms.Padding(2);
            this.latviaNo.Name = "latviaNo";
            this.latviaNo.Size = new System.Drawing.Size(18, 17);
            this.latviaNo.TabIndex = 81;
            this.latviaNo.UseVisualStyleBackColor = true;
            this.latviaNo.CheckedChanged += new System.EventHandler(this.latviaNo_CheckedChanged);
            // 
            // latviaYes
            // 
            this.latviaYes.AutoSize = true;
            this.latviaYes.Checked = true;
            this.latviaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.latviaYes.Location = new System.Drawing.Point(682, 494);
            this.latviaYes.Margin = new System.Windows.Forms.Padding(2);
            this.latviaYes.Name = "latviaYes";
            this.latviaYes.Size = new System.Drawing.Size(18, 17);
            this.latviaYes.TabIndex = 80;
            this.latviaYes.UseVisualStyleBackColor = true;
            this.latviaYes.CheckedChanged += new System.EventHandler(this.latviaYes_CheckedChanged);
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::EU_Voting_Calculator.Properties.Resources.Lithuania;
            this.pictureBox17.Location = new System.Drawing.Point(407, 533);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(62, 52);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 83;
            this.pictureBox17.TabStop = false;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.SystemColors.Control;
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox19.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(478, 548);
            this.textBox19.Margin = new System.Windows.Forms.Padding(2);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(155, 32);
            this.textBox19.TabIndex = 84;
            this.textBox19.Text = "Lithuania - 0.62%";
            // 
            // lithuaniaAbstain
            // 
            this.lithuaniaAbstain.AutoSize = true;
            this.lithuaniaAbstain.Location = new System.Drawing.Point(740, 554);
            this.lithuaniaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.lithuaniaAbstain.Name = "lithuaniaAbstain";
            this.lithuaniaAbstain.Size = new System.Drawing.Size(18, 17);
            this.lithuaniaAbstain.TabIndex = 87;
            this.lithuaniaAbstain.UseVisualStyleBackColor = true;
            this.lithuaniaAbstain.CheckedChanged += new System.EventHandler(this.lithuaniaAbstain_CheckedChanged);
            // 
            // lithuaniaNo
            // 
            this.lithuaniaNo.AutoSize = true;
            this.lithuaniaNo.Location = new System.Drawing.Point(711, 554);
            this.lithuaniaNo.Margin = new System.Windows.Forms.Padding(2);
            this.lithuaniaNo.Name = "lithuaniaNo";
            this.lithuaniaNo.Size = new System.Drawing.Size(18, 17);
            this.lithuaniaNo.TabIndex = 86;
            this.lithuaniaNo.UseVisualStyleBackColor = true;
            this.lithuaniaNo.CheckedChanged += new System.EventHandler(this.lithuaniaNo_CheckedChanged);
            // 
            // lithuaniaYes
            // 
            this.lithuaniaYes.AutoSize = true;
            this.lithuaniaYes.Checked = true;
            this.lithuaniaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.lithuaniaYes.Location = new System.Drawing.Point(682, 554);
            this.lithuaniaYes.Margin = new System.Windows.Forms.Padding(2);
            this.lithuaniaYes.Name = "lithuaniaYes";
            this.lithuaniaYes.Size = new System.Drawing.Size(18, 17);
            this.lithuaniaYes.TabIndex = 85;
            this.lithuaniaYes.UseVisualStyleBackColor = true;
            this.lithuaniaYes.CheckedChanged += new System.EventHandler(this.lithuaniaYes_CheckedChanged);
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::EU_Voting_Calculator.Properties.Resources.Luxembourg;
            this.pictureBox18.Location = new System.Drawing.Point(407, 590);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(62, 52);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 88;
            this.pictureBox18.TabStop = false;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.SystemColors.Control;
            this.textBox20.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox20.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(478, 604);
            this.textBox20.Margin = new System.Windows.Forms.Padding(2);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(173, 32);
            this.textBox20.TabIndex = 89;
            this.textBox20.Text = "Luxembourg - 0.14%";
            // 
            // luxembourgAbstain
            // 
            this.luxembourgAbstain.AutoSize = true;
            this.luxembourgAbstain.Location = new System.Drawing.Point(740, 613);
            this.luxembourgAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.luxembourgAbstain.Name = "luxembourgAbstain";
            this.luxembourgAbstain.Size = new System.Drawing.Size(18, 17);
            this.luxembourgAbstain.TabIndex = 92;
            this.luxembourgAbstain.UseVisualStyleBackColor = true;
            this.luxembourgAbstain.CheckedChanged += new System.EventHandler(this.luxembourgAbstain_CheckedChanged);
            // 
            // luxembourgNo
            // 
            this.luxembourgNo.AutoSize = true;
            this.luxembourgNo.Location = new System.Drawing.Point(711, 613);
            this.luxembourgNo.Margin = new System.Windows.Forms.Padding(2);
            this.luxembourgNo.Name = "luxembourgNo";
            this.luxembourgNo.Size = new System.Drawing.Size(18, 17);
            this.luxembourgNo.TabIndex = 91;
            this.luxembourgNo.UseVisualStyleBackColor = true;
            this.luxembourgNo.CheckedChanged += new System.EventHandler(this.luxembourgNo_CheckedChanged);
            // 
            // luxembourgYes
            // 
            this.luxembourgYes.AutoSize = true;
            this.luxembourgYes.Checked = true;
            this.luxembourgYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.luxembourgYes.Location = new System.Drawing.Point(682, 613);
            this.luxembourgYes.Margin = new System.Windows.Forms.Padding(2);
            this.luxembourgYes.Name = "luxembourgYes";
            this.luxembourgYes.Size = new System.Drawing.Size(18, 17);
            this.luxembourgYes.TabIndex = 90;
            this.luxembourgYes.UseVisualStyleBackColor = true;
            this.luxembourgYes.CheckedChanged += new System.EventHandler(this.luxembourgYes_CheckedChanged);
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::EU_Voting_Calculator.Properties.Resources.Malta;
            this.pictureBox19.Location = new System.Drawing.Point(779, 136);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(62, 52);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 93;
            this.pictureBox19.TabStop = false;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.SystemColors.Control;
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox21.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(850, 150);
            this.textBox21.Margin = new System.Windows.Forms.Padding(2);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(155, 32);
            this.textBox21.TabIndex = 94;
            this.textBox21.Text = "Malta - 0.11%";
            // 
            // maltaAbstain
            // 
            this.maltaAbstain.AutoSize = true;
            this.maltaAbstain.Location = new System.Drawing.Point(1120, 158);
            this.maltaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.maltaAbstain.Name = "maltaAbstain";
            this.maltaAbstain.Size = new System.Drawing.Size(18, 17);
            this.maltaAbstain.TabIndex = 97;
            this.maltaAbstain.UseVisualStyleBackColor = true;
            this.maltaAbstain.CheckedChanged += new System.EventHandler(this.maltaAbstain_CheckedChanged);
            // 
            // maltaNo
            // 
            this.maltaNo.AutoSize = true;
            this.maltaNo.Location = new System.Drawing.Point(1091, 158);
            this.maltaNo.Margin = new System.Windows.Forms.Padding(2);
            this.maltaNo.Name = "maltaNo";
            this.maltaNo.Size = new System.Drawing.Size(18, 17);
            this.maltaNo.TabIndex = 96;
            this.maltaNo.UseVisualStyleBackColor = true;
            this.maltaNo.CheckedChanged += new System.EventHandler(this.maltaNo_CheckedChanged);
            // 
            // maltaYes
            // 
            this.maltaYes.AutoSize = true;
            this.maltaYes.Checked = true;
            this.maltaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.maltaYes.Location = new System.Drawing.Point(1062, 158);
            this.maltaYes.Margin = new System.Windows.Forms.Padding(2);
            this.maltaYes.Name = "maltaYes";
            this.maltaYes.Size = new System.Drawing.Size(18, 17);
            this.maltaYes.TabIndex = 95;
            this.maltaYes.UseVisualStyleBackColor = true;
            this.maltaYes.CheckedChanged += new System.EventHandler(this.maltaYes_CheckedChanged);
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::EU_Voting_Calculator.Properties.Resources.Netherlands;
            this.pictureBox20.Location = new System.Drawing.Point(779, 193);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(62, 52);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 98;
            this.pictureBox20.TabStop = false;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.SystemColors.Control;
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox22.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(850, 207);
            this.textBox22.Margin = new System.Windows.Forms.Padding(2);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(173, 32);
            this.textBox22.TabIndex = 99;
            this.textBox22.Text = "Netherlands - 3.89%";
            // 
            // netherlandsAbstain
            // 
            this.netherlandsAbstain.AutoSize = true;
            this.netherlandsAbstain.Location = new System.Drawing.Point(1120, 215);
            this.netherlandsAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.netherlandsAbstain.Name = "netherlandsAbstain";
            this.netherlandsAbstain.Size = new System.Drawing.Size(18, 17);
            this.netherlandsAbstain.TabIndex = 102;
            this.netherlandsAbstain.UseVisualStyleBackColor = true;
            this.netherlandsAbstain.CheckedChanged += new System.EventHandler(this.netherlandsAbstain_CheckedChanged);
            // 
            // netherlandsNo
            // 
            this.netherlandsNo.AutoSize = true;
            this.netherlandsNo.Location = new System.Drawing.Point(1091, 215);
            this.netherlandsNo.Margin = new System.Windows.Forms.Padding(2);
            this.netherlandsNo.Name = "netherlandsNo";
            this.netherlandsNo.Size = new System.Drawing.Size(18, 17);
            this.netherlandsNo.TabIndex = 101;
            this.netherlandsNo.UseVisualStyleBackColor = true;
            this.netherlandsNo.CheckedChanged += new System.EventHandler(this.netherlandsNo_CheckedChanged);
            // 
            // netherlandsYes
            // 
            this.netherlandsYes.AutoSize = true;
            this.netherlandsYes.Checked = true;
            this.netherlandsYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.netherlandsYes.Location = new System.Drawing.Point(1062, 215);
            this.netherlandsYes.Margin = new System.Windows.Forms.Padding(2);
            this.netherlandsYes.Name = "netherlandsYes";
            this.netherlandsYes.Size = new System.Drawing.Size(18, 17);
            this.netherlandsYes.TabIndex = 100;
            this.netherlandsYes.UseVisualStyleBackColor = true;
            this.netherlandsYes.CheckedChanged += new System.EventHandler(this.netherlandsYes_CheckedChanged);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::EU_Voting_Calculator.Properties.Resources.Poland;
            this.pictureBox21.Location = new System.Drawing.Point(779, 250);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(62, 52);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 103;
            this.pictureBox21.TabStop = false;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.SystemColors.Control;
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox23.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(850, 265);
            this.textBox23.Margin = new System.Windows.Forms.Padding(2);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(131, 32);
            this.textBox23.TabIndex = 104;
            this.textBox23.Text = "Poland - 8.49%";
            // 
            // polandAbstain
            // 
            this.polandAbstain.AutoSize = true;
            this.polandAbstain.Location = new System.Drawing.Point(1120, 274);
            this.polandAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.polandAbstain.Name = "polandAbstain";
            this.polandAbstain.Size = new System.Drawing.Size(18, 17);
            this.polandAbstain.TabIndex = 107;
            this.polandAbstain.UseVisualStyleBackColor = true;
            this.polandAbstain.CheckedChanged += new System.EventHandler(this.polandAbstain_CheckedChanged);
            // 
            // polandNo
            // 
            this.polandNo.AutoSize = true;
            this.polandNo.Location = new System.Drawing.Point(1091, 274);
            this.polandNo.Margin = new System.Windows.Forms.Padding(2);
            this.polandNo.Name = "polandNo";
            this.polandNo.Size = new System.Drawing.Size(18, 17);
            this.polandNo.TabIndex = 106;
            this.polandNo.UseVisualStyleBackColor = true;
            this.polandNo.CheckedChanged += new System.EventHandler(this.polandNo_CheckedChanged);
            // 
            // polandYes
            // 
            this.polandYes.AutoSize = true;
            this.polandYes.Checked = true;
            this.polandYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.polandYes.Location = new System.Drawing.Point(1062, 274);
            this.polandYes.Margin = new System.Windows.Forms.Padding(2);
            this.polandYes.Name = "polandYes";
            this.polandYes.Size = new System.Drawing.Size(18, 17);
            this.polandYes.TabIndex = 105;
            this.polandYes.UseVisualStyleBackColor = true;
            this.polandYes.CheckedChanged += new System.EventHandler(this.polandYes_CheckedChanged);
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::EU_Voting_Calculator.Properties.Resources.Portugal;
            this.pictureBox22.Location = new System.Drawing.Point(779, 306);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(62, 52);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 108;
            this.pictureBox22.TabStop = false;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.SystemColors.Control;
            this.textBox24.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox24.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(850, 323);
            this.textBox24.Margin = new System.Windows.Forms.Padding(2);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(144, 32);
            this.textBox24.TabIndex = 109;
            this.textBox24.Text = "Portugal - 2.30%";
            // 
            // portugalAbstain
            // 
            this.portugalAbstain.AutoSize = true;
            this.portugalAbstain.Location = new System.Drawing.Point(1120, 331);
            this.portugalAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.portugalAbstain.Name = "portugalAbstain";
            this.portugalAbstain.Size = new System.Drawing.Size(18, 17);
            this.portugalAbstain.TabIndex = 112;
            this.portugalAbstain.UseVisualStyleBackColor = true;
            this.portugalAbstain.CheckedChanged += new System.EventHandler(this.portugalAbstain_CheckedChanged);
            // 
            // portugalNo
            // 
            this.portugalNo.AutoSize = true;
            this.portugalNo.Location = new System.Drawing.Point(1091, 331);
            this.portugalNo.Margin = new System.Windows.Forms.Padding(2);
            this.portugalNo.Name = "portugalNo";
            this.portugalNo.Size = new System.Drawing.Size(18, 17);
            this.portugalNo.TabIndex = 111;
            this.portugalNo.UseVisualStyleBackColor = true;
            this.portugalNo.CheckedChanged += new System.EventHandler(this.portugalNo_CheckedChanged);
            // 
            // portugalYes
            // 
            this.portugalYes.AutoSize = true;
            this.portugalYes.Checked = true;
            this.portugalYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.portugalYes.Location = new System.Drawing.Point(1062, 331);
            this.portugalYes.Margin = new System.Windows.Forms.Padding(2);
            this.portugalYes.Name = "portugalYes";
            this.portugalYes.Size = new System.Drawing.Size(18, 17);
            this.portugalYes.TabIndex = 110;
            this.portugalYes.UseVisualStyleBackColor = true;
            this.portugalYes.CheckedChanged += new System.EventHandler(this.portugalYes_CheckedChanged);
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::EU_Voting_Calculator.Properties.Resources.Romania;
            this.pictureBox23.Location = new System.Drawing.Point(779, 363);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(62, 52);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 113;
            this.pictureBox23.TabStop = false;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.SystemColors.Control;
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox25.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(850, 379);
            this.textBox25.Margin = new System.Windows.Forms.Padding(2);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(155, 32);
            this.textBox25.TabIndex = 114;
            this.textBox25.Text = "Romania - 4.34%";
            // 
            // romaniaAbstain
            // 
            this.romaniaAbstain.AutoSize = true;
            this.romaniaAbstain.Location = new System.Drawing.Point(1120, 387);
            this.romaniaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.romaniaAbstain.Name = "romaniaAbstain";
            this.romaniaAbstain.Size = new System.Drawing.Size(18, 17);
            this.romaniaAbstain.TabIndex = 117;
            this.romaniaAbstain.UseVisualStyleBackColor = true;
            this.romaniaAbstain.CheckedChanged += new System.EventHandler(this.romaniaAbstain_CheckedChanged);
            // 
            // romaniaNo
            // 
            this.romaniaNo.AutoSize = true;
            this.romaniaNo.Location = new System.Drawing.Point(1091, 387);
            this.romaniaNo.Margin = new System.Windows.Forms.Padding(2);
            this.romaniaNo.Name = "romaniaNo";
            this.romaniaNo.Size = new System.Drawing.Size(18, 17);
            this.romaniaNo.TabIndex = 116;
            this.romaniaNo.UseVisualStyleBackColor = true;
            this.romaniaNo.CheckedChanged += new System.EventHandler(this.romaniaNo_CheckedChanged);
            // 
            // romaniaYes
            // 
            this.romaniaYes.AutoSize = true;
            this.romaniaYes.Checked = true;
            this.romaniaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.romaniaYes.Location = new System.Drawing.Point(1062, 387);
            this.romaniaYes.Margin = new System.Windows.Forms.Padding(2);
            this.romaniaYes.Name = "romaniaYes";
            this.romaniaYes.Size = new System.Drawing.Size(18, 17);
            this.romaniaYes.TabIndex = 115;
            this.romaniaYes.UseVisualStyleBackColor = true;
            this.romaniaYes.CheckedChanged += new System.EventHandler(this.romaniaYes_CheckedChanged);
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::EU_Voting_Calculator.Properties.Resources.Slovakia;
            this.pictureBox24.Location = new System.Drawing.Point(779, 420);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(62, 52);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 118;
            this.pictureBox24.TabStop = false;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.Control;
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox26.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(850, 435);
            this.textBox26.Margin = new System.Windows.Forms.Padding(2);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(144, 32);
            this.textBox26.TabIndex = 119;
            this.textBox26.Text = "Slovakia - 1.22%";
            // 
            // slovakiaAbstain
            // 
            this.slovakiaAbstain.AutoSize = true;
            this.slovakiaAbstain.Location = new System.Drawing.Point(1120, 444);
            this.slovakiaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.slovakiaAbstain.Name = "slovakiaAbstain";
            this.slovakiaAbstain.Size = new System.Drawing.Size(18, 17);
            this.slovakiaAbstain.TabIndex = 122;
            this.slovakiaAbstain.UseVisualStyleBackColor = true;
            this.slovakiaAbstain.CheckedChanged += new System.EventHandler(this.slovakiaAbstain_CheckedChanged);
            // 
            // slovakiaNo
            // 
            this.slovakiaNo.AutoSize = true;
            this.slovakiaNo.Location = new System.Drawing.Point(1091, 444);
            this.slovakiaNo.Margin = new System.Windows.Forms.Padding(2);
            this.slovakiaNo.Name = "slovakiaNo";
            this.slovakiaNo.Size = new System.Drawing.Size(18, 17);
            this.slovakiaNo.TabIndex = 121;
            this.slovakiaNo.UseVisualStyleBackColor = true;
            this.slovakiaNo.CheckedChanged += new System.EventHandler(this.slovakiaNo_CheckedChanged);
            // 
            // slovakiaYes
            // 
            this.slovakiaYes.AutoSize = true;
            this.slovakiaYes.Checked = true;
            this.slovakiaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.slovakiaYes.Location = new System.Drawing.Point(1062, 444);
            this.slovakiaYes.Margin = new System.Windows.Forms.Padding(2);
            this.slovakiaYes.Name = "slovakiaYes";
            this.slovakiaYes.Size = new System.Drawing.Size(18, 17);
            this.slovakiaYes.TabIndex = 120;
            this.slovakiaYes.UseVisualStyleBackColor = true;
            this.slovakiaYes.CheckedChanged += new System.EventHandler(this.slovakiaYes_CheckedChanged);
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::EU_Voting_Calculator.Properties.Resources.Slovenia;
            this.pictureBox25.Location = new System.Drawing.Point(779, 477);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(62, 52);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 123;
            this.pictureBox25.TabStop = false;
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.SystemColors.Control;
            this.textBox27.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox27.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(850, 494);
            this.textBox27.Margin = new System.Windows.Forms.Padding(2);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(144, 32);
            this.textBox27.TabIndex = 124;
            this.textBox27.Text = "Slovenia - 0.47%";
            // 
            // sloveniaAbstain
            // 
            this.sloveniaAbstain.AutoSize = true;
            this.sloveniaAbstain.Location = new System.Drawing.Point(1120, 502);
            this.sloveniaAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.sloveniaAbstain.Name = "sloveniaAbstain";
            this.sloveniaAbstain.Size = new System.Drawing.Size(18, 17);
            this.sloveniaAbstain.TabIndex = 127;
            this.sloveniaAbstain.UseVisualStyleBackColor = true;
            this.sloveniaAbstain.CheckedChanged += new System.EventHandler(this.sloveniaAbstain_CheckedChanged);
            // 
            // sloveniaNo
            // 
            this.sloveniaNo.AutoSize = true;
            this.sloveniaNo.Location = new System.Drawing.Point(1091, 502);
            this.sloveniaNo.Margin = new System.Windows.Forms.Padding(2);
            this.sloveniaNo.Name = "sloveniaNo";
            this.sloveniaNo.Size = new System.Drawing.Size(18, 17);
            this.sloveniaNo.TabIndex = 126;
            this.sloveniaNo.UseVisualStyleBackColor = true;
            this.sloveniaNo.CheckedChanged += new System.EventHandler(this.sloveniaNo_CheckedChanged);
            // 
            // sloveniaYes
            // 
            this.sloveniaYes.AutoSize = true;
            this.sloveniaYes.Checked = true;
            this.sloveniaYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sloveniaYes.Location = new System.Drawing.Point(1062, 502);
            this.sloveniaYes.Margin = new System.Windows.Forms.Padding(2);
            this.sloveniaYes.Name = "sloveniaYes";
            this.sloveniaYes.Size = new System.Drawing.Size(18, 17);
            this.sloveniaYes.TabIndex = 125;
            this.sloveniaYes.UseVisualStyleBackColor = true;
            this.sloveniaYes.CheckedChanged += new System.EventHandler(this.sloveniaYes_CheckedChanged);
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::EU_Voting_Calculator.Properties.Resources.Spain;
            this.pictureBox26.Location = new System.Drawing.Point(779, 534);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(62, 52);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 128;
            this.pictureBox26.TabStop = false;
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.SystemColors.Control;
            this.textBox28.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox28.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(850, 551);
            this.textBox28.Margin = new System.Windows.Forms.Padding(2);
            this.textBox28.Name = "textBox28";
            this.textBox28.ReadOnly = true;
            this.textBox28.Size = new System.Drawing.Size(131, 32);
            this.textBox28.TabIndex = 129;
            this.textBox28.Text = "Spain - 10.49%";
            // 
            // spainAbstain
            // 
            this.spainAbstain.AutoSize = true;
            this.spainAbstain.Location = new System.Drawing.Point(1120, 560);
            this.spainAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.spainAbstain.Name = "spainAbstain";
            this.spainAbstain.Size = new System.Drawing.Size(18, 17);
            this.spainAbstain.TabIndex = 132;
            this.spainAbstain.UseVisualStyleBackColor = true;
            this.spainAbstain.CheckedChanged += new System.EventHandler(this.spainAbstain_CheckedChanged);
            // 
            // spainNo
            // 
            this.spainNo.AutoSize = true;
            this.spainNo.Location = new System.Drawing.Point(1091, 560);
            this.spainNo.Margin = new System.Windows.Forms.Padding(2);
            this.spainNo.Name = "spainNo";
            this.spainNo.Size = new System.Drawing.Size(18, 17);
            this.spainNo.TabIndex = 131;
            this.spainNo.UseVisualStyleBackColor = true;
            this.spainNo.CheckedChanged += new System.EventHandler(this.spainNo_CheckedChanged);
            // 
            // spainYes
            // 
            this.spainYes.AutoSize = true;
            this.spainYes.Checked = true;
            this.spainYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.spainYes.Location = new System.Drawing.Point(1062, 560);
            this.spainYes.Margin = new System.Windows.Forms.Padding(2);
            this.spainYes.Name = "spainYes";
            this.spainYes.Size = new System.Drawing.Size(18, 17);
            this.spainYes.TabIndex = 130;
            this.spainYes.UseVisualStyleBackColor = true;
            this.spainYes.CheckedChanged += new System.EventHandler(this.spainYes_CheckedChanged);
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::EU_Voting_Calculator.Properties.Resources.Sweden;
            this.pictureBox27.Location = new System.Drawing.Point(779, 592);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(62, 52);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 133;
            this.pictureBox27.TabStop = false;
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.SystemColors.Control;
            this.textBox29.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox29.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(850, 607);
            this.textBox29.Margin = new System.Windows.Forms.Padding(2);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(142, 32);
            this.textBox29.TabIndex = 134;
            this.textBox29.Text = "Sweden - 2.29%";
            // 
            // swedenAbstain
            // 
            this.swedenAbstain.AutoSize = true;
            this.swedenAbstain.Location = new System.Drawing.Point(1120, 616);
            this.swedenAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.swedenAbstain.Name = "swedenAbstain";
            this.swedenAbstain.Size = new System.Drawing.Size(18, 17);
            this.swedenAbstain.TabIndex = 137;
            this.swedenAbstain.UseVisualStyleBackColor = true;
            this.swedenAbstain.CheckedChanged += new System.EventHandler(this.swedenAbstain_CheckedChanged);
            // 
            // swedenNo
            // 
            this.swedenNo.AutoSize = true;
            this.swedenNo.Location = new System.Drawing.Point(1091, 616);
            this.swedenNo.Margin = new System.Windows.Forms.Padding(2);
            this.swedenNo.Name = "swedenNo";
            this.swedenNo.Size = new System.Drawing.Size(18, 17);
            this.swedenNo.TabIndex = 136;
            this.swedenNo.UseVisualStyleBackColor = true;
            this.swedenNo.CheckedChanged += new System.EventHandler(this.swedenNo_CheckedChanged);
            // 
            // swedenYes
            // 
            this.swedenYes.AutoSize = true;
            this.swedenYes.Checked = true;
            this.swedenYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.swedenYes.Location = new System.Drawing.Point(1062, 616);
            this.swedenYes.Margin = new System.Windows.Forms.Padding(2);
            this.swedenYes.Name = "swedenYes";
            this.swedenYes.Size = new System.Drawing.Size(18, 17);
            this.swedenYes.TabIndex = 135;
            this.swedenYes.UseVisualStyleBackColor = true;
            this.swedenYes.CheckedChanged += new System.EventHandler(this.swedenYes_CheckedChanged);
            // 
            // resultText
            // 
            this.resultText.BackColor = System.Drawing.SystemColors.Control;
            this.resultText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.resultText.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultText.Location = new System.Drawing.Point(0, 709);
            this.resultText.Margin = new System.Windows.Forms.Padding(2);
            this.resultText.Name = "resultText";
            this.resultText.ReadOnly = true;
            this.resultText.Size = new System.Drawing.Size(1261, 31);
            this.resultText.TabIndex = 138;
            this.resultText.Text = "Result: Approved";
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.SystemColors.Control;
            this.textBox32.Font = new System.Drawing.Font("Segoe UI", 16.25F, System.Drawing.FontStyle.Bold);
            this.textBox32.Location = new System.Drawing.Point(311, 72);
            this.textBox32.Margin = new System.Windows.Forms.Padding(2);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(72, 44);
            this.textBox32.TabIndex = 141;
            this.textBox32.Text = "Vote";
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.SystemColors.Control;
            this.textBox30.Font = new System.Drawing.Font("Segoe UI", 16.25F, System.Drawing.FontStyle.Bold);
            this.textBox30.Location = new System.Drawing.Point(779, 72);
            this.textBox30.Margin = new System.Windows.Forms.Padding(2);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(229, 44);
            this.textBox30.TabIndex = 142;
            this.textBox30.Text = "Country";
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.SystemColors.Control;
            this.textBox31.Font = new System.Drawing.Font("Segoe UI", 16.25F, System.Drawing.FontStyle.Bold);
            this.textBox31.Location = new System.Drawing.Point(407, 72);
            this.textBox31.Margin = new System.Windows.Forms.Padding(2);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(244, 44);
            this.textBox31.TabIndex = 143;
            this.textBox31.Text = "Country";
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.SystemColors.Control;
            this.textBox33.Font = new System.Drawing.Font("Segoe UI", 16.25F, System.Drawing.FontStyle.Bold);
            this.textBox33.Location = new System.Drawing.Point(1062, 72);
            this.textBox33.Margin = new System.Windows.Forms.Padding(2);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(73, 44);
            this.textBox33.TabIndex = 144;
            this.textBox33.Text = "Vote";
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.SystemColors.Control;
            this.textBox34.Font = new System.Drawing.Font("Segoe UI", 16.25F, System.Drawing.FontStyle.Bold);
            this.textBox34.Location = new System.Drawing.Point(682, 72);
            this.textBox34.Margin = new System.Windows.Forms.Padding(2);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(73, 44);
            this.textBox34.TabIndex = 145;
            this.textBox34.Text = "Vote";
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.SystemColors.Control;
            this.textBox35.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox35.Location = new System.Drawing.Point(303, 110);
            this.textBox35.Margin = new System.Windows.Forms.Padding(2);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(27, 30);
            this.textBox35.TabIndex = 146;
            this.textBox35.Text = "Y";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.SystemColors.Control;
            this.textBox36.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox36.Location = new System.Drawing.Point(334, 110);
            this.textBox36.Margin = new System.Windows.Forms.Padding(2);
            this.textBox36.Name = "textBox36";
            this.textBox36.ReadOnly = true;
            this.textBox36.Size = new System.Drawing.Size(27, 30);
            this.textBox36.TabIndex = 147;
            this.textBox36.Text = "N";
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.SystemColors.Control;
            this.textBox37.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox37.Location = new System.Drawing.Point(364, 110);
            this.textBox37.Margin = new System.Windows.Forms.Padding(2);
            this.textBox37.Name = "textBox37";
            this.textBox37.ReadOnly = true;
            this.textBox37.Size = new System.Drawing.Size(27, 30);
            this.textBox37.TabIndex = 148;
            this.textBox37.Text = "AB";
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.SystemColors.Control;
            this.textBox38.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox38.Location = new System.Drawing.Point(735, 110);
            this.textBox38.Margin = new System.Windows.Forms.Padding(2);
            this.textBox38.Name = "textBox38";
            this.textBox38.ReadOnly = true;
            this.textBox38.Size = new System.Drawing.Size(27, 30);
            this.textBox38.TabIndex = 151;
            this.textBox38.Text = "AB";
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.SystemColors.Control;
            this.textBox39.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox39.Location = new System.Drawing.Point(705, 110);
            this.textBox39.Margin = new System.Windows.Forms.Padding(2);
            this.textBox39.Name = "textBox39";
            this.textBox39.ReadOnly = true;
            this.textBox39.Size = new System.Drawing.Size(27, 30);
            this.textBox39.TabIndex = 150;
            this.textBox39.Text = "N";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.SystemColors.Control;
            this.textBox40.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox40.Location = new System.Drawing.Point(674, 110);
            this.textBox40.Margin = new System.Windows.Forms.Padding(2);
            this.textBox40.Name = "textBox40";
            this.textBox40.ReadOnly = true;
            this.textBox40.Size = new System.Drawing.Size(27, 30);
            this.textBox40.TabIndex = 149;
            this.textBox40.Text = "Y";
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.SystemColors.Control;
            this.textBox41.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox41.Location = new System.Drawing.Point(1116, 110);
            this.textBox41.Margin = new System.Windows.Forms.Padding(2);
            this.textBox41.Name = "textBox41";
            this.textBox41.ReadOnly = true;
            this.textBox41.Size = new System.Drawing.Size(27, 30);
            this.textBox41.TabIndex = 154;
            this.textBox41.Text = "AB";
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.SystemColors.Control;
            this.textBox42.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox42.Location = new System.Drawing.Point(1086, 110);
            this.textBox42.Margin = new System.Windows.Forms.Padding(2);
            this.textBox42.Name = "textBox42";
            this.textBox42.ReadOnly = true;
            this.textBox42.Size = new System.Drawing.Size(27, 30);
            this.textBox42.TabIndex = 153;
            this.textBox42.Text = "N";
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.SystemColors.Control;
            this.textBox43.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.textBox43.Location = new System.Drawing.Point(1055, 110);
            this.textBox43.Margin = new System.Windows.Forms.Padding(2);
            this.textBox43.Name = "textBox43";
            this.textBox43.ReadOnly = true;
            this.textBox43.Size = new System.Drawing.Size(27, 30);
            this.textBox43.TabIndex = 152;
            this.textBox43.Text = "Y";
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.SystemColors.Control;
            this.textBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox44.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(15, 11);
            this.textBox44.Margin = new System.Windows.Forms.Padding(2);
            this.textBox44.Name = "textBox44";
            this.textBox44.ReadOnly = true;
            this.textBox44.Size = new System.Drawing.Size(204, 32);
            this.textBox44.TabIndex = 155;
            this.textBox44.Text = "KEY:";
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.SystemColors.Control;
            this.textBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox45.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.textBox45.Location = new System.Drawing.Point(72, 41);
            this.textBox45.Margin = new System.Windows.Forms.Padding(2);
            this.textBox45.Name = "textBox45";
            this.textBox45.ReadOnly = true;
            this.textBox45.Size = new System.Drawing.Size(53, 23);
            this.textBox45.TabIndex = 156;
            this.textBox45.Text = "N = NO";
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.SystemColors.Control;
            this.textBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox46.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.textBox46.Location = new System.Drawing.Point(129, 41);
            this.textBox46.Margin = new System.Windows.Forms.Padding(2);
            this.textBox46.Name = "textBox46";
            this.textBox46.ReadOnly = true;
            this.textBox46.Size = new System.Drawing.Size(90, 23);
            this.textBox46.TabIndex = 157;
            this.textBox46.Text = "AB = ABSTAIN";
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.Control;
            this.textBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox47.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.textBox47.Location = new System.Drawing.Point(15, 41);
            this.textBox47.Margin = new System.Windows.Forms.Padding(2);
            this.textBox47.Name = "textBox47";
            this.textBox47.ReadOnly = true;
            this.textBox47.Size = new System.Drawing.Size(53, 23);
            this.textBox47.TabIndex = 158;
            this.textBox47.Text = "Y = YES";
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // requiredText
            // 
            this.requiredText.BackColor = System.Drawing.SystemColors.Control;
            this.requiredText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.requiredText.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.requiredText.Location = new System.Drawing.Point(0, 753);
            this.requiredText.Margin = new System.Windows.Forms.Padding(2);
            this.requiredText.Name = "requiredText";
            this.requiredText.ReadOnly = true;
            this.requiredText.Size = new System.Drawing.Size(1243, 31);
            this.requiredText.TabIndex = 159;
            this.requiredText.Text = "Required For Adoption: \r\n";
            // 
            // irelandAbstain
            // 
            this.irelandAbstain.AutoSize = true;
            this.irelandAbstain.Location = new System.Drawing.Point(741, 381);
            this.irelandAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.irelandAbstain.Name = "irelandAbstain";
            this.irelandAbstain.Size = new System.Drawing.Size(18, 17);
            this.irelandAbstain.TabIndex = 72;
            this.irelandAbstain.UseVisualStyleBackColor = true;
            this.irelandAbstain.CheckedChanged += new System.EventHandler(this.irelandAbstain_CheckedChanged);
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.Control;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(478, 146);
            this.textBox12.Margin = new System.Windows.Forms.Padding(2);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(142, 32);
            this.textBox12.TabIndex = 49;
            this.textBox12.Text = "France - 14.98%";
            // 
            // franceYes
            // 
            this.franceYes.AutoSize = true;
            this.franceYes.Checked = true;
            this.franceYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.franceYes.Location = new System.Drawing.Point(684, 152);
            this.franceYes.Margin = new System.Windows.Forms.Padding(2);
            this.franceYes.Name = "franceYes";
            this.franceYes.Size = new System.Drawing.Size(18, 17);
            this.franceYes.TabIndex = 50;
            this.franceYes.UseVisualStyleBackColor = true;
            this.franceYes.CheckedChanged += new System.EventHandler(this.franceYes_CheckedChanged);
            // 
            // franceNo
            // 
            this.franceNo.AutoSize = true;
            this.franceNo.Location = new System.Drawing.Point(712, 152);
            this.franceNo.Margin = new System.Windows.Forms.Padding(2);
            this.franceNo.Name = "franceNo";
            this.franceNo.Size = new System.Drawing.Size(18, 17);
            this.franceNo.TabIndex = 51;
            this.franceNo.UseVisualStyleBackColor = true;
            this.franceNo.CheckedChanged += new System.EventHandler(this.franceNo_CheckedChanged);
            // 
            // franceAbstain
            // 
            this.franceAbstain.AutoSize = true;
            this.franceAbstain.Location = new System.Drawing.Point(741, 152);
            this.franceAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.franceAbstain.Name = "franceAbstain";
            this.franceAbstain.Size = new System.Drawing.Size(18, 17);
            this.franceAbstain.TabIndex = 52;
            this.franceAbstain.UseVisualStyleBackColor = true;
            this.franceAbstain.CheckedChanged += new System.EventHandler(this.franceAbstain_CheckedChanged);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::EU_Voting_Calculator.Properties.Resources.France;
            this.pictureBox10.Location = new System.Drawing.Point(408, 132);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(62, 52);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 48;
            this.pictureBox10.TabStop = false;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.Control;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(479, 204);
            this.textBox13.Margin = new System.Windows.Forms.Padding(2);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(158, 32);
            this.textBox13.TabIndex = 54;
            this.textBox13.Text = "Germany - 18.54%";
            // 
            // germanyYes
            // 
            this.germanyYes.AutoSize = true;
            this.germanyYes.Checked = true;
            this.germanyYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.germanyYes.Location = new System.Drawing.Point(684, 211);
            this.germanyYes.Margin = new System.Windows.Forms.Padding(2);
            this.germanyYes.Name = "germanyYes";
            this.germanyYes.Size = new System.Drawing.Size(18, 17);
            this.germanyYes.TabIndex = 55;
            this.germanyYes.UseVisualStyleBackColor = true;
            this.germanyYes.CheckedChanged += new System.EventHandler(this.germanyYes_CheckedChanged);
            // 
            // germanyNo
            // 
            this.germanyNo.AutoSize = true;
            this.germanyNo.Location = new System.Drawing.Point(712, 211);
            this.germanyNo.Margin = new System.Windows.Forms.Padding(2);
            this.germanyNo.Name = "germanyNo";
            this.germanyNo.Size = new System.Drawing.Size(18, 17);
            this.germanyNo.TabIndex = 56;
            this.germanyNo.UseVisualStyleBackColor = true;
            this.germanyNo.CheckedChanged += new System.EventHandler(this.germanyNo_CheckedChanged);
            // 
            // germanyAbstain
            // 
            this.germanyAbstain.AutoSize = true;
            this.germanyAbstain.Location = new System.Drawing.Point(741, 211);
            this.germanyAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.germanyAbstain.Name = "germanyAbstain";
            this.germanyAbstain.Size = new System.Drawing.Size(18, 17);
            this.germanyAbstain.TabIndex = 57;
            this.germanyAbstain.UseVisualStyleBackColor = true;
            this.germanyAbstain.CheckedChanged += new System.EventHandler(this.germanyAbstain_CheckedChanged);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::EU_Voting_Calculator.Properties.Resources.Greece;
            this.pictureBox12.Location = new System.Drawing.Point(408, 245);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(62, 52);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 58;
            this.pictureBox12.TabStop = false;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.Control;
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox14.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(479, 261);
            this.textBox14.Margin = new System.Windows.Forms.Padding(2);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(142, 32);
            this.textBox14.TabIndex = 59;
            this.textBox14.Text = "Greece - 2.40%";
            // 
            // greeceYes
            // 
            this.greeceYes.AutoSize = true;
            this.greeceYes.Checked = true;
            this.greeceYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.greeceYes.Location = new System.Drawing.Point(684, 268);
            this.greeceYes.Margin = new System.Windows.Forms.Padding(2);
            this.greeceYes.Name = "greeceYes";
            this.greeceYes.Size = new System.Drawing.Size(18, 17);
            this.greeceYes.TabIndex = 60;
            this.greeceYes.UseVisualStyleBackColor = true;
            this.greeceYes.CheckedChanged += new System.EventHandler(this.greeceYes_CheckedChanged);
            // 
            // greeceNo
            // 
            this.greeceNo.AutoSize = true;
            this.greeceNo.Location = new System.Drawing.Point(712, 268);
            this.greeceNo.Margin = new System.Windows.Forms.Padding(2);
            this.greeceNo.Name = "greeceNo";
            this.greeceNo.Size = new System.Drawing.Size(18, 17);
            this.greeceNo.TabIndex = 61;
            this.greeceNo.UseVisualStyleBackColor = true;
            this.greeceNo.CheckedChanged += new System.EventHandler(this.greeceNo_CheckedChanged);
            // 
            // greeceAbstain
            // 
            this.greeceAbstain.AutoSize = true;
            this.greeceAbstain.Location = new System.Drawing.Point(741, 268);
            this.greeceAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.greeceAbstain.Name = "greeceAbstain";
            this.greeceAbstain.Size = new System.Drawing.Size(18, 17);
            this.greeceAbstain.TabIndex = 62;
            this.greeceAbstain.UseVisualStyleBackColor = true;
            this.greeceAbstain.CheckedChanged += new System.EventHandler(this.greeceAbstain_CheckedChanged);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::EU_Voting_Calculator.Properties.Resources.Hungary;
            this.pictureBox13.Location = new System.Drawing.Point(408, 302);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(62, 52);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 63;
            this.pictureBox13.TabStop = false;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.SystemColors.Control;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(479, 317);
            this.textBox15.Margin = new System.Windows.Forms.Padding(2);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(142, 32);
            this.textBox15.TabIndex = 64;
            this.textBox15.Text = "Hungary - 2.18%";
            // 
            // hungaryYes
            // 
            this.hungaryYes.AutoSize = true;
            this.hungaryYes.Checked = true;
            this.hungaryYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.hungaryYes.Location = new System.Drawing.Point(684, 324);
            this.hungaryYes.Margin = new System.Windows.Forms.Padding(2);
            this.hungaryYes.Name = "hungaryYes";
            this.hungaryYes.Size = new System.Drawing.Size(18, 17);
            this.hungaryYes.TabIndex = 65;
            this.hungaryYes.UseVisualStyleBackColor = true;
            this.hungaryYes.CheckedChanged += new System.EventHandler(this.hungaryYes_CheckedChanged);
            // 
            // hungaryNo
            // 
            this.hungaryNo.AutoSize = true;
            this.hungaryNo.Location = new System.Drawing.Point(712, 324);
            this.hungaryNo.Margin = new System.Windows.Forms.Padding(2);
            this.hungaryNo.Name = "hungaryNo";
            this.hungaryNo.Size = new System.Drawing.Size(18, 17);
            this.hungaryNo.TabIndex = 66;
            this.hungaryNo.UseVisualStyleBackColor = true;
            this.hungaryNo.CheckedChanged += new System.EventHandler(this.hungaryNo_CheckedChanged);
            // 
            // hungaryAbstain
            // 
            this.hungaryAbstain.AutoSize = true;
            this.hungaryAbstain.Location = new System.Drawing.Point(741, 324);
            this.hungaryAbstain.Margin = new System.Windows.Forms.Padding(2);
            this.hungaryAbstain.Name = "hungaryAbstain";
            this.hungaryAbstain.Size = new System.Drawing.Size(18, 17);
            this.hungaryAbstain.TabIndex = 67;
            this.hungaryAbstain.UseVisualStyleBackColor = true;
            this.hungaryAbstain.CheckedChanged += new System.EventHandler(this.hungaryAbstain_CheckedChanged);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::EU_Voting_Calculator.Properties.Resources.Ireland;
            this.pictureBox14.Location = new System.Drawing.Point(408, 359);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(62, 52);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 68;
            this.pictureBox14.TabStop = false;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.SystemColors.Control;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(478, 372);
            this.textBox16.Margin = new System.Windows.Forms.Padding(2);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(142, 32);
            this.textBox16.TabIndex = 69;
            this.textBox16.Text = "Ireland - 1.10%";
            // 
            // irelandYes
            // 
            this.irelandYes.AutoSize = true;
            this.irelandYes.Checked = true;
            this.irelandYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.irelandYes.Location = new System.Drawing.Point(684, 381);
            this.irelandYes.Margin = new System.Windows.Forms.Padding(2);
            this.irelandYes.Name = "irelandYes";
            this.irelandYes.Size = new System.Drawing.Size(18, 17);
            this.irelandYes.TabIndex = 70;
            this.irelandYes.UseVisualStyleBackColor = true;
            this.irelandYes.CheckedChanged += new System.EventHandler(this.irelandYes_CheckedChanged);
            // 
            // irelandNo
            // 
            this.irelandNo.AutoSize = true;
            this.irelandNo.Location = new System.Drawing.Point(712, 381);
            this.irelandNo.Margin = new System.Windows.Forms.Padding(2);
            this.irelandNo.Name = "irelandNo";
            this.irelandNo.Size = new System.Drawing.Size(18, 17);
            this.irelandNo.TabIndex = 71;
            this.irelandNo.UseVisualStyleBackColor = true;
            this.irelandNo.CheckedChanged += new System.EventHandler(this.irelandNo_CheckedChanged);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::EU_Voting_Calculator.Properties.Resources.Germany;
            this.pictureBox11.Location = new System.Drawing.Point(408, 188);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(62, 52);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 53;
            this.pictureBox11.TabStop = false;
            // 
            // ruleBox
            // 
            this.ruleBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ruleBox.FormattingEnabled = true;
            this.ruleBox.Location = new System.Drawing.Point(1170, 110);
            this.ruleBox.Name = "ruleBox";
            this.ruleBox.Size = new System.Drawing.Size(227, 26);
            this.ruleBox.TabIndex = 160;
            this.ruleBox.SelectedIndexChanged += new System.EventHandler(this.ruleBox_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1399, 795);
            this.Controls.Add(this.ruleBox);
            this.Controls.Add(this.requiredText);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.resultText);
            this.Controls.Add(this.swedenAbstain);
            this.Controls.Add(this.swedenNo);
            this.Controls.Add(this.swedenYes);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.spainAbstain);
            this.Controls.Add(this.spainNo);
            this.Controls.Add(this.spainYes);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.sloveniaAbstain);
            this.Controls.Add(this.sloveniaNo);
            this.Controls.Add(this.sloveniaYes);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.slovakiaAbstain);
            this.Controls.Add(this.slovakiaNo);
            this.Controls.Add(this.slovakiaYes);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.romaniaAbstain);
            this.Controls.Add(this.romaniaNo);
            this.Controls.Add(this.romaniaYes);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.portugalAbstain);
            this.Controls.Add(this.portugalNo);
            this.Controls.Add(this.portugalYes);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.polandAbstain);
            this.Controls.Add(this.polandNo);
            this.Controls.Add(this.polandYes);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.netherlandsAbstain);
            this.Controls.Add(this.netherlandsNo);
            this.Controls.Add(this.netherlandsYes);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.maltaAbstain);
            this.Controls.Add(this.maltaNo);
            this.Controls.Add(this.maltaYes);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.luxembourgAbstain);
            this.Controls.Add(this.luxembourgNo);
            this.Controls.Add(this.luxembourgYes);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.lithuaniaAbstain);
            this.Controls.Add(this.lithuaniaNo);
            this.Controls.Add(this.lithuaniaYes);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.latviaAbstain);
            this.Controls.Add(this.latviaNo);
            this.Controls.Add(this.latviaYes);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.italyAbstain);
            this.Controls.Add(this.italyNo);
            this.Controls.Add(this.italyYes);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.irelandAbstain);
            this.Controls.Add(this.irelandNo);
            this.Controls.Add(this.irelandYes);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.hungaryAbstain);
            this.Controls.Add(this.hungaryNo);
            this.Controls.Add(this.hungaryYes);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.greeceAbstain);
            this.Controls.Add(this.greeceNo);
            this.Controls.Add(this.greeceYes);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.germanyAbstain);
            this.Controls.Add(this.germanyNo);
            this.Controls.Add(this.germanyYes);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.franceAbstain);
            this.Controls.Add(this.franceNo);
            this.Controls.Add(this.franceYes);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.finlandAbstain);
            this.Controls.Add(this.finlandNo);
            this.Controls.Add(this.finlandYes);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.estoniaAbstain);
            this.Controls.Add(this.estoniaNo);
            this.Controls.Add(this.estoniaYes);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.denmarkAbstain);
            this.Controls.Add(this.denmarkNo);
            this.Controls.Add(this.denmarkYes);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.czechiaAbstain);
            this.Controls.Add(this.czechiaNo);
            this.Controls.Add(this.czechiaYes);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.cyprusAbstain);
            this.Controls.Add(this.cyprusNo);
            this.Controls.Add(this.cyprusYes);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.croatiaAbstain);
            this.Controls.Add(this.croatiaNo);
            this.Controls.Add(this.croatiaYes);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.bulgariaAbstain);
            this.Controls.Add(this.bulgariaNo);
            this.Controls.Add(this.bulgariaYes);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.belgiumAbstain);
            this.Controls.Add(this.belgiumNo);
            this.Controls.Add(this.belgiumYes);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.austriaAbstain);
            this.Controls.Add(this.austriaNo);
            this.Controls.Add(this.austriaYes);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.resetAllyes);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button resetAllyes;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox austriaYes;
        private System.Windows.Forms.CheckBox austriaNo;
        private System.Windows.Forms.CheckBox austriaAbstain;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckBox belgiumAbstain;
        private System.Windows.Forms.CheckBox belgiumNo;
        private System.Windows.Forms.CheckBox belgiumYes;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.CheckBox bulgariaAbstain;
        private System.Windows.Forms.CheckBox bulgariaNo;
        private System.Windows.Forms.CheckBox bulgariaYes;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.CheckBox croatiaAbstain;
        private System.Windows.Forms.CheckBox croatiaNo;
        private System.Windows.Forms.CheckBox croatiaYes;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.CheckBox cyprusAbstain;
        private System.Windows.Forms.CheckBox cyprusNo;
        private System.Windows.Forms.CheckBox cyprusYes;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.CheckBox czechiaAbstain;
        private System.Windows.Forms.CheckBox czechiaNo;
        private System.Windows.Forms.CheckBox czechiaYes;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.CheckBox denmarkAbstain;
        private System.Windows.Forms.CheckBox denmarkNo;
        private System.Windows.Forms.CheckBox denmarkYes;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.CheckBox estoniaAbstain;
        private System.Windows.Forms.CheckBox estoniaNo;
        private System.Windows.Forms.CheckBox estoniaYes;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.CheckBox finlandAbstain;
        private System.Windows.Forms.CheckBox finlandNo;
        private System.Windows.Forms.CheckBox finlandYes;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.CheckBox italyAbstain;
        private System.Windows.Forms.CheckBox italyNo;
        private System.Windows.Forms.CheckBox italyYes;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.CheckBox latviaAbstain;
        private System.Windows.Forms.CheckBox latviaNo;
        private System.Windows.Forms.CheckBox latviaYes;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.CheckBox lithuaniaAbstain;
        private System.Windows.Forms.CheckBox lithuaniaNo;
        private System.Windows.Forms.CheckBox lithuaniaYes;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.CheckBox luxembourgAbstain;
        private System.Windows.Forms.CheckBox luxembourgNo;
        private System.Windows.Forms.CheckBox luxembourgYes;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.CheckBox maltaAbstain;
        private System.Windows.Forms.CheckBox maltaNo;
        private System.Windows.Forms.CheckBox maltaYes;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.CheckBox netherlandsAbstain;
        private System.Windows.Forms.CheckBox netherlandsNo;
        private System.Windows.Forms.CheckBox netherlandsYes;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.CheckBox polandAbstain;
        private System.Windows.Forms.CheckBox polandNo;
        private System.Windows.Forms.CheckBox polandYes;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.CheckBox portugalAbstain;
        private System.Windows.Forms.CheckBox portugalNo;
        private System.Windows.Forms.CheckBox portugalYes;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.CheckBox romaniaAbstain;
        private System.Windows.Forms.CheckBox romaniaNo;
        private System.Windows.Forms.CheckBox romaniaYes;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.CheckBox slovakiaAbstain;
        private System.Windows.Forms.CheckBox slovakiaNo;
        private System.Windows.Forms.CheckBox slovakiaYes;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.CheckBox sloveniaAbstain;
        private System.Windows.Forms.CheckBox sloveniaNo;
        private System.Windows.Forms.CheckBox sloveniaYes;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.CheckBox spainAbstain;
        private System.Windows.Forms.CheckBox spainNo;
        private System.Windows.Forms.CheckBox spainYes;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.CheckBox swedenAbstain;
        private System.Windows.Forms.CheckBox swedenNo;
        private System.Windows.Forms.CheckBox swedenYes;
        private System.Windows.Forms.TextBox resultText;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox requiredText;
        private System.Windows.Forms.CheckBox irelandAbstain;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.CheckBox franceYes;
        private System.Windows.Forms.CheckBox franceNo;
        private System.Windows.Forms.CheckBox franceAbstain;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.CheckBox germanyYes;
        private System.Windows.Forms.CheckBox germanyNo;
        private System.Windows.Forms.CheckBox germanyAbstain;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.CheckBox greeceYes;
        private System.Windows.Forms.CheckBox greeceNo;
        private System.Windows.Forms.CheckBox greeceAbstain;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.CheckBox hungaryYes;
        private System.Windows.Forms.CheckBox hungaryNo;
        private System.Windows.Forms.CheckBox hungaryAbstain;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.CheckBox irelandYes;
        private System.Windows.Forms.CheckBox irelandNo;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.ComboBox ruleBox;
    }
}

