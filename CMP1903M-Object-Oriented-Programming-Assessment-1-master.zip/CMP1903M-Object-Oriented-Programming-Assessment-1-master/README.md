# CMP1903M-Object-Oriented-Programming-Assessment-1
EU Voting Calculator
